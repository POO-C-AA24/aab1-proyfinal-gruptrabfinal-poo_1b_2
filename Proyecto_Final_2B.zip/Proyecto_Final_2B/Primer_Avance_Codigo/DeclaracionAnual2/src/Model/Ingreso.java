package Model;

public class Ingreso {
    private double sueldoMensual;

    public Ingreso(double sueldoMensual) {
        this.sueldoMensual = sueldoMensual;
    }

    public double getSueldoMensual() {
        return sueldoMensual;
    }
}
