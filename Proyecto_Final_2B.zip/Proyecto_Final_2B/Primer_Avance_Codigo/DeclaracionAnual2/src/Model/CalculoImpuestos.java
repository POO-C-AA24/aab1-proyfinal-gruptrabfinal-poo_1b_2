package Model;

public class CalculoImpuestos {
    public double calcularImpuestos(Usuario usuario) {
        double totalIngresos = usuario.getIngresos().stream().mapToDouble(Ingreso::getSueldoMensual).sum();

        double totalDeducciones = usuario.getFacturas().stream().mapToDouble(Tipo_Factura::getMontoMaximo).sum();

        double impuestos = totalIngresos - totalDeducciones;
        return impuestos;
    }
}
