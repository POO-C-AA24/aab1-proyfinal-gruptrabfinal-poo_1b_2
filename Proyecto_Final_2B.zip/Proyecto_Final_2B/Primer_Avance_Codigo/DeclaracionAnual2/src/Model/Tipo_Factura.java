package Model;

public abstract class Tipo_Factura {
    private double sueldo;
    private String fecha;

    public Tipo_Factura(double sueldo, String fecha) {
        this.sueldo = sueldo;
        this.fecha = fecha;
    }

    public double getSueldo() {
        return sueldo;
    }

    public String getFecha() {
        return fecha;
    }

    public abstract double getMontoMaximo();

    public static class Factura_Vivienda extends Tipo_Factura {
        public Factura_Vivienda(double sueldo, String fecha) {
            super(sueldo, fecha);
        }

        @Override
        public double getMontoMaximo() {
            return getSueldo() * 0.1;
        }
    }

    public static class Factura_Educación extends Tipo_Factura {
        public Factura_Educación(double sueldo, String fecha) {
            super(sueldo, fecha);
        }

        @Override
        public double getMontoMaximo() {
            return 800;
        }
    }

    public static class Factura_Alimentación extends Tipo_Factura {
        public Factura_Alimentación(double sueldo, String fecha) {
            super(sueldo, fecha);
        }

        @Override
        public double getMontoMaximo() {
            return getSueldo() * 0.1;
        }
    }

    public static class Factura_Vestimenta extends Tipo_Factura {
        public Factura_Vestimenta(double sueldo, String fecha) {
            super(sueldo, fecha);
        }

        @Override
        public double getMontoMaximo() {
            return 100;
        }
    }

    public static class Factura_Salud extends Tipo_Factura {
        public Factura_Salud(double sueldo, String fecha) {
            super(sueldo, fecha);
        }

        @Override
        public double getMontoMaximo() {
            return Math.min(getSueldo() * 0.2, 300);
        }
    }

    public static class Factura_Turismo extends Tipo_Factura {
        public Factura_Turismo(double sueldo, String fecha) {
            super(sueldo, fecha);
        }

        @Override
        public double getMontoMaximo() {
            return 100;
        }
    }
}
