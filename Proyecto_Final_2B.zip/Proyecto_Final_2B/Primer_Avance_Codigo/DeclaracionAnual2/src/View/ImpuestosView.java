package View;

import Controller.Impuestos;
import Model.Usuario;

public class ImpuestosView {
    public void mostrarDeclaracion(Usuario usuario) {
        Impuestos controller = new Impuestos(usuario);
        double impuestos = controller.calcularImpuestos();

        System.out.println("Declaración de Impuestos");
        System.out.println("Nombre: " + usuario.getNombre());
        System.out.println("DNI: " + usuario.getDni());
        System.out.println("Impuestos a pagar: " + impuestos);
    }
}
