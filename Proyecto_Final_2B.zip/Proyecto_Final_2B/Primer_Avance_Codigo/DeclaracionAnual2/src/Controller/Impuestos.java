package Controller;

import Model.Usuario;
import Model.Ingreso;
import Model.Tipo_Factura;

public class Impuestos {
    private Usuario usuario;

    public Impuestos(Usuario usuario) {
        this.usuario = usuario;
    }

    public double calcularImpuestos() {
        double totalIngresosMensuales = 0;
        double totalDeducciones = 0;
        
        //  total de ingresos mensuales
        for (Ingreso ingreso : usuario.getIngresos()) {
            totalIngresosMensuales += ingreso.getSueldoMensual();
        }
        
        //  total de deducciones
        for (Tipo_Factura factura : usuario.getFacturas()) {
            totalDeducciones += factura.getMontoMaximo();
        }

        // Calcular ingresos anuales
        double totalIngresosAnuales = (totalIngresosMensuales * 12);

        // Calcular impuestos
        double impuestos = totalIngresosAnuales - totalDeducciones;
        return impuestos;
    }
}
